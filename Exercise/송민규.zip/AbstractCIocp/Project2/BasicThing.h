#pragma once
#pragma comment(lib, "ws2_32")
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<deque>
#include <winsock2.h>
#include <ws2tcpip.h>

enum STATUS
{
	START = 1,
	LOBBY,
	LGSI,
	DISCONNECTED
};


enum IO_TYPE
{
	recvIO = 1,
	sendIO,
	acceptIO,

};

class _BUFFER
{
private:
	char* buf;
	int left;
	int completed;
	int buftsize;
public:
	_BUFFER(int size);
	_BUFFER(IO_TYPE iotype, int size, int psize);
	char* getbuf();
	void setleft(int a);
	void fcompleted(int a);
	bool is_completed();
	char* getresult();
	int getleft();
	int getcompleted();
	void recvclear();
	~_BUFFER();
};

struct LoginInfo
{
	char ID[20];
	char PW[20];
	int uuid;
};

struct ExOverlapped
{
	OVERLAPPED overlapped;
	IO_TYPE type;
	void* clientLP;
};

